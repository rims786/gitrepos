package book;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/book")	//main URI
public class Book {

	@GET	// POST/
	@Produces(MediaType.TEXT_HTML)	//Produces to client or Consumes from client. TEXT/XML/JSON
	public String sayHelloHTML() {
		
		String response = null;
		response = "<hi>This is HTML response</hi>";
		return response;
		
	}
	
	@GET	// 
	@Produces(MediaType.TEXT_XML)	//Produces to client or Consumes from client. TEXT/XML/JSON
	public String sayHelloXML() {
		
		String response = null;
		response = "<?xml version='1.0'?>" + "<hello>Hello XML</hello>";
		return response;
		
	}
	
	
//	@GET	// 
//	@Produces(MediaType.APPLICATION_JSON)	//Produces to client or Consumes from client. TEXT/XML/JSON
//	public String sayHelloJason() {
//		
//		String response = null;
//		return response;
//		
//	}
}
